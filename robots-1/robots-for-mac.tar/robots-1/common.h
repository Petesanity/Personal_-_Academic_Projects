
#ifndef COMMON_H
#define COMMON_H

enum tile {EMPTY, DIAMOND};

#endif
