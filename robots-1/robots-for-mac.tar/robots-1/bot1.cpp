
#include <cstdlib>
#include <iostream>
#include "bot1.h"

using namespace std;

static loc target;

void init_robot(int w, int h, loc robot, ostream &log) {
  log << "Hello" << endl; 
  target.x = robot.x;
  target.y = robot.y;
}

action choose_next_step(int w, int h, loc robot, vector<loc> dm, ostream &log) {
  target = dm[0];
  log << "goto (" << target.x << "," << target.y << "); ";
  return RIGHT;  
}
