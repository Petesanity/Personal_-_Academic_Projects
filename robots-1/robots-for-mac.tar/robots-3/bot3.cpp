
#include <cstdlib>
#include <iostream>
#include "bot3.h"

using namespace std;


void init_robot(int w, int h, loc robot, ostream &log) {
  log << "Start." << endl;
}

action step_randomly() {
  int x = rand() % 4;
  if (x == 0)
    return UP;
  else if (x == 1)
    return RIGHT;
  else if (x == 2)
    return DOWN;
  else
    return LEFT;
}

action choose_next_step(int w, int h, loc robot, const vector< vector<tile> > map, ostream &log) 
{
  log << "Something useful for debugging";
  action dir = step_randomly();
  return dir;
}
